# Word-Search-Puzzle-Solver

# Kristo Abdi Wiguna - 13520058
```bash 
Tugas Kecil 1 IF 2211 Strategi Algoritma
PENYELESAIAN WORD SEARCH PUZZLE DENGAN ALGORITMA BRUTE FORCE
Semester 2 Tahun 2021/2022
```
## Requirement
```bash
C++14
```

## Setup
After cloning the repository
```bash 
cd word-search-puzzle-solver
1. Place the text file you want to solve in the folder test
2. Open the bin folder, click the main.exe 
3. Input the name of the file you want to solve (ex: `test.txt`)
4. If you want to solve another puzzle, type `y`, otherwise, type `n`
```
